package tests;

import org.testng.annotations.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import pages.LoginPage;

import static org.testng.Assert.*;

public class LoginTest {

    WebDriver driver;
    LoginPage login;

    @BeforeMethod
    public void setUp() {
        driver = new ChromeDriver();
        driver.get("https://www.amazon.in/ap/signin?");
        login = new LoginPage(driver);
    }

    @Test
    public void validLoginTest() {
        login.enterEmail("umeshpathakk@gmail.com");
        login.enterPassword("Test@123");
        login.clickLogin();
        assertTrue(login.getCurrentUrl().contains("dashboard"));
    }

    @AfterMethod
    public void tearDown() {
        driver.quit();
    }
}

package apitests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.*;

public class OrderApiTest {

    @Test
    public void testOrderStatusApi() {
        Response res = RestAssured
            .given()
            .when()
            .get("https://api.example.com/orders/12345");

        res.then().statusCode(200);
        res.then().body("orderId", equalTo(12345));
    }
}

package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage
{
    WebDriver driver;

    By emailField = By.id("email");
    By passwordField = By.id("password");
    By loginButton = By.id("loginBtn");

    public LoginPage(WebDriver driver)
    {
        this.driver = driver;
    }

    public void enterEmail(String email)
    {
        driver.findElement(emailField).sendKeys(email);
    }

    public void enterPassword(String password)
    {
        driver.findElement(passwordField).sendKeys(password);
    }

    public void clickLogin()
    {
        driver.findElement(loginButton).click();
    }

    public String getCurrentUrl()
    {
        return driver.getCurrentUrl();
    }
}
